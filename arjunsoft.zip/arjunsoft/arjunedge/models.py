from __future__ import unicode_literals
from django.contrib.postgres.fields import JSONField
from django.db import models
from django.contrib.auth.models import (BaseUserManager, AbstractBaseUser)
class organization(models.Model):
	
	# unique OrgId
	OrgId =  models.AutoField(primary_key=True, unique=True)
	# unique OrgName
	OrgName = models.CharField(max_length=200, unique = True)
	def __unicode__(self):	
		return self.OrgName
	
# Create your models here.
class MyUserManager(BaseUserManager):

	def create_user(self,username, OrgName, email, password=None):
		if not username:
			raise ValueError('Users must provide a username')
		user = self.model( username = username, email=self.normalize_email(email),OrgName = OrgName,)
		user.set_password(password)
		user.save(using=self._db)
		return user
	def create_superuser(self, username, OrgName, email , password):

		user = self.create_user(username = username, email = email, password=password, OrgName= OrgName,)
		user.is_active = True
		user.is_superuser = True
		user.is_staff = True
		user.save(using=self._db)
     		return user

class MyUser(AbstractBaseUser):
	username =  models.CharField(max_length=200, unique = True)
	OrgId= models.ForeignKey(organization, on_delete=models.CASCADE, null =True)
	OrgName = models.CharField(max_length=200)
	email = models.EmailField(verbose_name='email address',max_length=255,unique=True,)
	is_active = models.BooleanField(default=True)
	is_admin = models.BooleanField(default=False)
	is_staff =  models.BooleanField(default=False)
	is_superuser = models.BooleanField(default = False)
	objects = MyUserManager()

	REQUIRED_FIELDS = ['OrgName', 'email']
	USERNAME_FIELD = 'username' 
	def get_full_name(self):
	# The user is identified by their email address
		return self.email
	def get_short_name(self):
	# The user is identified by their email address
		return self.email
	def __str__(self):              # __unicode__ on Python 2
		return self.email
	def has_perm(self, perm, obj=None):
	#"Does the user have a specific permission?"
	# Simplest possible answer: Yes, always
		return True
	def has_module_perms(self, app_label):
	#"Does the user have permissions to view the app `app_label`?"
	# Simplest possible answer: Yes, always
		return True
	



class dataFlow(models.Model):
	
	# DataFlowId is an unique identifier for 
	DataFlowId =  models.AutoField(primary_key=True, unique=True)
	# Name of the Dataflow 
	Name = models.CharField(max_length=200, unique = True)
	#SourceName used to query source objects
	SourceName = models.CharField(max_length=200)
	# FilterName used to query filter objects
	FilterName = models.CharField(max_length=200, null =True, blank =True)
	# ProcessName used to query Process objects
	ProcessName = models.CharField(max_length = 200)
	# TargetName used to query Target objects
	TargetName = models.CharField(max_length=200)
	# connector to organization
	OrganizationId = models.ForeignKey(organization, on_delete=models.CASCADE, null =True)
	def __unicode__(self):	
		return self.Name

class source(models.Model):
	
	# Unique identifier for Source
	SourceId = models.AutoField(primary_key=True, unique=True)
	# Name of the Source
	Name = models.CharField(max_length=200, unique = True)
	# Platform Name 
	Platform =  models.CharField(max_length=200, null =True, blank = True)
	# OrgName 
	OrgName = models.CharField(max_length=200)
	# UserName
	Username = models.CharField(max_length = 200)
	# Password
	Password = models.CharField(max_length=200)
	# DataFlow
	OrganizationId = models.ForeignKey(organization, on_delete=models.CASCADE, null = True, blank = True)
	def __unicode__(self):	
		return self.Name

class filter(models.Model):
	
	# FilterId
	FilterId =  models.AutoField(primary_key=True, unique=True)
	# Name
	Name = models.CharField(max_length=200, unique=True)	
	#
	Filterset = JSONField(null = True, blank = True)
	# DataflowId 
	OrganizationId = models.ForeignKey(organization, on_delete=models.CASCADE, null = True, blank = True)
	def __unicode__(self):	
		return self.Name

class filterAttribute(models.Model):

	#Attribute 
	AttributeId = models.AutoField(primary_key=True, unique=True)
	#what they want to filter by
	Criterion =  models.CharField(max_length=200)
	#Operator: >, <, greater than or = , less than or equal to, equal to, not equal to inbetween
	Operator = models.CharField(max_length=200)
	# Value they are filtering Criterion based on
	Value =  models.CharField(max_length=200)
	# And or Or
	LogicalOperator = models.CharField(max_length=200)
	#connector to filter
	FilterId = models.ForeignKey(filter, on_delete=models.CASCADE)

class process(models.Model):

	#  
	ProcessId =   models.AutoField(primary_key=True, unique=True)
	# 
	Name = models.CharField(max_length=200, unique = True)
	# 
	PlanningLevel = models.CharField(max_length=200, null = True, blank = True)
	# 
	OrganizationId = models.ForeignKey(organization, on_delete=models.CASCADE, null = True, blank = True)
	def __unicode__(self):	
		return self.Name

class Target(models.Model):
	
	# 
	TargetId = models.AutoField(primary_key=True, unique=True)
	#
	Name = models.CharField(max_length=200, unique = True)
	#
	Token = models.CharField(max_length=200)
	#
	#
	OrganizationId = models.ForeignKey(organization, on_delete=models.CASCADE, null = True, blank = True)
	
	def __unicode__(self):	
		return self.Name
