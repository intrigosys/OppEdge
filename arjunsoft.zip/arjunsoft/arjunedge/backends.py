from django.contrib.auth import get_user_model
from arjunedge.models import organization
MyUser = get_user_model()
class MyCustomBackend(object):
    # Create an authentication method
    # This is called by the standard Django login procedure
    def authenticate(self, username=None, password=None, orgName = None):
        OrgMatch = False
        try:
            # Try to find a user matching your username
            user = MyUser.objects.get(username=username, OrgName = orgName)
            agam = user.OrgName
            try:
                org = organization.objects.get(OrgName =  agam)
                OrgMatch = True

                if user.username == username and user.password == password:
                    return user
                else:
                    return None

            except organization.DoesNotExist:
                return None
        except MyUser.DoesNotExist:
            # No user was found, return None - triggers default login failed
            return None

    def get_user(self, user_id):
        
        try:
            return MyUser.objects.get(pk=user_id)

        except MyUser.DoesNotExist:
            return None