from django.conf.urls import url
from .forms import SourceForm
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^register$', views.userregistration, name ='register'),
    #url(r'^source', views.ssource, name = 'source'),
    url(r'^addsource', views.addsource, name ='addsource'),
    #url(r'^filter', views.filterz, name = 'filter'),
    url(r'^addfilter', views.addfilter, name ='filter'),
    url(r'^addprocess', views.addprocess, name ='addprocess'),
    #url(r'^target', views.ttarget, name = 'target'),
    url(r'^addtarget', views.addtarget, name ='addtarget'),
    #url(r'^dataflow', views.ddataflow, name = 'dataflow' ),
    url(r'^adddataflow', views.adddataflow, name = 'adddataflow' ),
    url(r'^createcsv', views.addcsv, name = 'createcsv' ),
    #url(r'^addcsv', views.addcsv, name = 'addcsv' ),
    url(r'^home', views.home, name = 'home' ),
]