from django.shortcuts import render, redirect
from django.forms.formsets import formset_factory
from django.http import HttpResponse
from .forms import SourceForm, ProcessForm, TargetForm, DataFlowForm, CreateForm, LoginForm, FilterAttributeForm, FilterForm
from arjunedge.models import organization, source, process, Target, dataFlow, filter, filterAttribute
from csvgen import preprocess, WriteListToCSV, preprocess2, filterBy
from django.contrib.auth import login, authenticate, logout 
from django.contrib.auth.decorators import login_required
from arjunedge.admin import UserCreationForm
from filetransfers.api import serve_file
import beatbox
import csv
import json
import dropbox
import ast
# Create your views here.

def index(request):
    return render(request, "particles-static.html")
#def log(request):
#   form  = LoginForm()
#   return render(request,"login.html",  {'form': form})
def customLogin(request):
    if request.user.is_authenticated():
        return redirect(home)
    else:
        if request.method == 'POST':
            form = LoginForm(request.POST, request.FILES)
            #if form.is_valid():
            user = authenticate(username = request.POST['username'], orgName = request.POST['organization'],password=request.POST['password'])
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect('http://127.0.0.1:8000/OppEdge/home')
                else:
                    print form.errors	
                    form=LoginForm()
                    return render(request, "login.html", {'form':form})
            else:
                print form.errors
                form = LoginForm()
                return render(request, "login.html", {'form': form}) 
        #else:
            #print form.errors
            #form = LoginForm()
            #return render(request, "login.html", {'form': form})
        else:
            form = LoginForm()
            return render(request,"login.html",  {'form': form})

#def ssource(request):
#    form = SourceForm()
#    return render(request, "first.html", {'form': form})
@login_required(login_url="http://127.0.0.1:8000/log")
def addsource(request):
    userOrg = request.user.OrgName
    if request.method == 'POST':
        form = SourceForm(request.POST, request.FILES)

        # Have we been provided with a valid form?
        if form.is_valid() :
            # Save the new category to the database.
            Name = request.POST['Name'] 
            Platf = request.POST.get('Platform')
            OrgName = request.POST.get('OrgName')
            Username = request.POST.get('Username')
            Password = request.POST.get('Password')
            answer = organization.objects.get(OrgName = userOrg)
            goku =  answer.source_set.create(Name = Name, Platform = Platf, OrgName = userOrg, 
            	Username = Username, Password = Password )
            # Now call the index() view.
            # The user will be shown the homepage.
            return redirect(home)
        else:
            # The supplied form contained errors - just print them to the terminal.
            print form.errors
            return redirect(addsource)
    else:
        # If the request was not a POST, display the form to enter details.
        form = SourceForm()  
        return render(request, "first.html",{'form':form})
@login_required(login_url="http://127.0.0.1:8000/log")
def addfilter(request):
   userOrg = request.user.OrgName
   theformset = formset_factory(FilterAttributeForm, extra = 1)
   if request.method == 'POST':
       form = FilterForm(request.POST)
       formset = theformset(request.POST)
       filtList = []
       for i in formset:
       	print i
       	ningus = []
       	filtform = i.save(commit = False)
       	crit = filtform.Criterion
       	opp = filtform.Operator
       	val = filtform.Value
       	logicopp = filtform.LogicalOperator
       	ningus.append(crit)
       	ningus.append(opp)
       	ningus.append(val)
       	ningus.append(logicopp)
       	filtList.append(ningus)
       filterSet = json.dumps(filtList, sort_keys=True)
       nameoffilt = form.save(commit = False)
       answer = organization.objects.get(OrgName = userOrg)
       goku =  answer.filter_set.create(Name = nameoffilt, Filterset= filterSet)
       return redirect(home)

   else:
       form = FilterForm()
       formset = theformset()
       return render(request, "filters.html",{'form':form, 'formset':formset})
@login_required(login_url="http://127.0.0.1:8000/log")
def addprocess(request):
    userOrg = request.user.OrgName
    if request.method == 'POST':
        form = ProcessForm(request.POST, request.FILES)

        # Have we been provided with a valid form?
        if form.is_valid() :
            # Save the new category to the database.
            Name = request.POST['Name'] 
            Process = request.POST.get('Process')
            answer = organization.objects.get(OrgName = userOrg)
            goku =  answer.process_set.create(Name = Name, PlanningLevel = Process)
            # Now call the index() view.
            # The user will be shown the homepage.
            return redirect(home)
        else:
            # The supplied form contained errors - just print them to the terminal.
            print form.errors
            return redirect(addprocess)
    else:
        # If the request was not a POST, display the form to enter details.
        form = ProcessForm()
        return render(request, "third.html", {'form': form})

@login_required(login_url="http://127.0.0.1:8000/log")
def adddataflow(request):
   userOrg = request.user.OrgName
   userOrgId = request.user.OrgId
   if request.method == 'POST':
        form = DataFlowForm(request.POST, request.FILES)

        # Have we been provided with a valid form?
        if form.is_valid() :
            # Save the new category to the database.
            Name = request.POST['Name'] 
            Source= request.POST.get('Source')
            Sourcr = source.objects.get(SourceId = Source)
            SourceName = Sourcr.Name
            Filter = request.POST.get('Filter')
            Filtrr = filter.objects.get(FilterId = Filter)
            FilterName = Filtrr.Name
            Process = request.POST.get('Process')
            Processr = process.objects.get(ProcessId = Process)
            ProcessName = Processr.Name
            Targe = request.POST.get('Target')
            Targetr = Target.objects.get(TargetId = Targe)
            TargetName = Targetr.Name
            answer = organization.objects.get(OrgName = userOrg)
            goku =  answer.dataflow_set.create(Name = Name, SourceName= SourceName, FilterName= FilterName,  ProcessName = ProcessName, TargetName = TargetName)

            # Now call the index() view.
            # The user will be shown the homepage.
            return redirect(home)
        else:
            # The supplied form contained errors - just print them to the terminal.
            print form.errors
            return redirect(adddataflow)
   else:
       # If the request was not a POST, display the form to enter details.
       form = DataFlowForm()
       form.fields['Source'].queryset = source.objects.filter(OrgName = userOrg)
       form.fields['Process'].queryset = process.objects.filter(OrganizationId = userOrgId)
       form.fields['Target'].queryset = Target.objects.filter(OrganizationId = userOrgId)
       form.fields['Filter'].queryset = filter.objects.filter(OrganizationId = userOrgId)
       return render(request, "fifth.html", {'form': form})
@login_required(login_url="http://127.0.0.1:8000/log")
def addcsv(request):
    userOrg = request.user.OrgName
    userOrgId = request.user.OrgId
    if request.method == 'POST':
        form = CreateForm(request.POST, request.FILES)
        # Have we been provided with a valid form?
        Name = request.POST.get('Dflow') 
        answer = organization.objects.get(OrgName= userOrg)
        print 
        d = dataFlow.objects.get(DataFlowId = Name)
        if (d != None): 
            # Save the new category to the database.
            s = d.SourceName
            p = d.ProcessName
            t = d.TargetName
            ambala = d.FilterName
            sourc = source.objects.get(Name = s, OrganizationId = userOrgId )
            use = sourc.Username
            pas = sourc.Password
            proces = process.objects.get(Name = p, OrganizationId = userOrgId)
            targe = Target.objects.get(Name = t, OrganizationId = userOrgId)
            filte = filter.objects.get(Name = ambala, OrganizationId = userOrgId)
            token = targe.Token
            csv_columns = ["Product Name", "Unit Price", "Quantity", "Product Code", "Opportunity Name", "Probability", "Close Date", "Type", "Opportunity ID"]
            sf = beatbox._tPartnerNS
            svc = beatbox.PythonClient()
            svc.login(use, pas)
            filteraf = filte.Filterset
            filterafs= ast.literal_eval(filteraf)
            qr = svc.query("SELECT Id, Name,Probability, CloseDate,  (SELECT Name, Product2.ProductCode, Quantity, UnitPrice FROM OpportunityLineItems)  FROM Opportunity " + filterBy(filterafs)  )
            q = preprocess2(qr)
            fil=WriteListToCSV(csv_columns, q)
            dbx = dropbox.Dropbox(token)
            f = open('tempFolder/OppData.csv')
            dbx.files_upload(f, '/OppData.csv', autorename =True)
            return redirect(home)
        else:
            # The supplied form contained errors - just print them to the terminal.
            print form.errors
            return redirect(addcsv)
    else:
       # If the request was not a POST, display the form to enter details.
       form = CreateForm()
       form.fields['Dflow'].queryset = dataFlow.objects.filter(OrganizationId = userOrgId)
       return render(request, "sixth.html", {'form':form})


def userregistration(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.clean_password2()
            form.save(commit = True)
            return redirect("http://127.0.0.1:8000/log")
        else:
            form = UserCreationForm()
            return render(request, "register.html", {'form': form})
    else:
        form = UserCreationForm()
        return render(request, "register.html", {'form': form})

@login_required(login_url="http://127.0.0.1:8000/log")
def user_logout(request):
    logout(request)
    # Since we know the user is logged in, we can now just log them out.
    return redirect("http://127.0.0.1:8000/log")

@login_required(login_url="http://127.0.0.1:8000/log")
def home(request):
    user = request.user.get_username
    return render(request,"home1.html")

#def ttarget(request):
 #  form = TargetForm()
   #return render(request, "fourth.html", {'form': form})
  
def addtarget(request):
    userOrg = request.user.OrgName
    if request.method == 'POST':
        form = TargetForm(request.POST, request.FILES)

        # Have we been provided with a valid form?
        if form.is_valid() :
            # Save the new category to the database.
            Name = request.POST['Name'] 
            Token = request.POST['Token']
            
            answer = organization.objects.get(OrgName = userOrg)
            goku =  answer.target_set.create(Name = Name, Token = Token)

            # Now call the index() view.
            # The user will be shown the homepage.
            return redirect(home)
        else:
            # The supplied form contained errors - just print them to the terminal.
            print form.errors
            return redirect(target)
    else:
        # If the request was not a POST, display the form to enter details.
        form = TargetForm()
        return render(request, 'fourth.html' , {'form':form})

#def ddataflow(request):
  # form = DataFlowForm()
   #return render(request, "fifth.html", {'form':form})


#def filteritup(request):
#     FilterFormSet = formset_factory(FilterAttributeForm)
#     if request.method == 'POST':
#         form1 = FilterForm(request.POST, request.FILES)
#         formset = FilterFormSet(request.POST)
#         #for i in formset:
#         return redirect("http://127.0.0.1:8000/log")
#     else:
#         form1 = FilterForm()
#         formset = FilterFormSet()
#         return render(request, "filters.html", {'form1': form1, 'formset':formset, })

#def filterthatstuff(request):
#   
#    if request.method == 'POST':
#        if request.POST['action'] == "+":
#            #extra = int(float(request.POST['extra'])) + 1
#            extra += 1
#            form = FilterForm(initial=request.POST)
#            formset = formset_factory(FilterAttributeForm, extra=extra)
#            return render(request, "filterfinal.html",{'form':form, 'formset':formset}) 
#        else:
#            extra = int(float(request.POST['extra']))
#            form = FilterForm(request.POST)
#            formset = formset_factory(FilterAttributeForm, extra=extra)(request.POST)
#
#            if form.is_valid() and formset.is_valid():
#                if request.POST['action'] == "Create":
#                    for form_c in formset:
#                        if not form_c.cleaned_data['delete']:
#                            return redirect("http://127.0.0.1:8000/log")
#                elif request.POST['action'] == "Edit":
#                    for form_c in formset:
#                        if form_c.cleaned_data['delete']:
#                            return redirect("http://127.0.0.1:8000/log")
#                        else:
#                            return redirect("http://127.0.0.1:8000/log")
#    else:
#        extra = 1
#        form = FilterForm()
#        formset = formset_factory(FilterAttributeForm, extra=extra)
#
#    #template = loader.get_template('some_template.html')
#    #context = RequestContext(request, {
#       # some context
    #})
#        return render(request, "filterfinal.html",{'form':form, 'formset':formset}) 

#def filterz(request):
#    return render(request,"filtergrid.html")