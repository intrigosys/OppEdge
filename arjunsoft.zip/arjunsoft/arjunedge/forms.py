from django.contrib.auth.forms import AuthenticationForm 
from django.contrib.auth import get_user_model
from django import forms
from django.forms import ModelForm,ModelChoiceField,ChoiceField
from .models import source, process, Target, dataFlow, filter, filterAttribute, organization
from django.forms.widgets import PasswordInput, TextInput, Select

# retrieves user model from settings. (the custom user model for OppEdge)
MyUser = get_user_model()

#login form to collect data from user and auntheticate the user.
class LoginForm(AuthenticationForm):
   #organization name used for authentication
    organization = forms.CharField(label="Organization", max_length=30, 
                             widget=forms.TextInput(attrs={'class': 'form-control', 'name': 'organization'}))
    # username of user used for authentication.
    username = forms.CharField(label="Username", max_length=30, 
                               widget=forms.TextInput(attrs={'class': 'form-control', 'name': 'username'}))
    #password of user used for authentication
    password = forms.CharField(label="Password", max_length=30, 
                               widget=forms.PasswordInput(attrs={'class': 'form-control', 'name': 'password'}))
    #class Meta:
    #   model = MyUser
    #    fields =['OrgName']
# Source form to collect source information and store in the backend
class SourceForm(forms.ModelForm):
    CHOICES = (
        ('Salesforce','Salesforce'),
    )
    Platform = forms.ChoiceField(label = 'Platform', choices=CHOICES, required=True, widget=forms.Select(attrs={'class': 'form-control', 'name': 'Platform'}))
    class Meta:
        model = source
        exclude = ['OrganizationId', 'Platform', 'OrgName']
        widgets = { 'Name': forms.TextInput(attrs={'class': 'form-control', 'name': 'Name'}), 
        'OrgName': forms.TextInput(attrs={'class': 'form-control', 'name': 'OrgName'}),
         'Username': forms.TextInput(attrs={'class': 'form-control', 'name': 'Username'}), 
         'Password': forms.TextInput(attrs={'class': 'form-control', 'name': 'Password'})}

#filter form to collect filter info and store in the backend
class FilterForm(forms.ModelForm):

    class Meta:
        model = filter
        fields = ['Name']
        widgets = { 'Name': forms.TextInput(attrs={'class': 'form-control', 'name': 'Name'})}
class FilterAttributeForm(forms.ModelForm):
    
    class Meta:
        model= filterAttribute
        exclude =['AttributeId', 'FilterId']
        widgets = { 'Criterion': forms.TextInput(attrs={'class': 'form-control', 'name': 'Criterion'}), 
        'Operator': forms.TextInput(attrs={'class': 'form-control', 'name': 'Operator'}),
        'Value': forms.TextInput(attrs={'class': 'form-control', 'name': 'Value'}),
         'LogicalOperator': forms.TextInput(attrs={'class': 'form-control', 'name': 'AND/OR'})}

# Process form to collect process information and store in the backend
class ProcessForm(forms.ModelForm):
    CHOICES = (
        ('IBP','SAP IBP FORMAT'),
    )
    Process = forms.ChoiceField(label = 'Process', choices=CHOICES, required=True, widget=forms.Select(attrs={'class': 'form-control', 'name': 'Process'}))
    class Meta:
        model = process
        exclude = ['OrganizationId', 'PlanningLevel']
        widgets = { 'Name': forms.TextInput(attrs={'class': 'form-control', 'name': 'Name'})}
# Target form to collect target information and store in the backend
class TargetForm(forms.ModelForm):
  
    class Meta:
        model = Target
        exclude = ['OrganizationId']
        widgets = { 'Name': forms.TextInput(attrs={'class': 'form-control', 'name': 'Name'}),
        'Token':forms.TextInput(attrs={'class': 'form-control', 'name': 'Token'})}


# DataFlow form to collect DataFlow information and store in the backend
class DataFlowForm(forms.ModelForm):
    Source = forms.ModelChoiceField(label = 'Source', queryset= source.objects.all(), empty_label="(Nothing)", widget=forms.Select(attrs={'class': 'form-control', 'name': 'Source'}))
    Filter = forms.ModelChoiceField(label = 'Filter', queryset= filter.objects.all(), empty_label="(Nothing)", widget=forms.Select(attrs={'class': 'form-control', 'name': 'Filter'}))
    Process = forms.ModelChoiceField(label= 'Process', queryset= process.objects.all(), empty_label="(Nothing)", widget=forms.Select(attrs={'class': 'form-control', 'name': 'Process'}))
    Target = forms.ModelChoiceField(label= 'Target', queryset= Target.objects.all(), empty_label="(Nothing)", widget=forms.Select(attrs={'class': 'form-control', 'name': 'Target'}))

    class Meta:
        model = dataFlow
        exclude = ['OrganizationId','TargetName','SourceName','FilterName','ProcessName']
        widgets = { 'Name': forms.TextInput(attrs={'class': 'form-control', 'name': 'Name'})}

# Create Form to allow users to pass in their dataflows and generate csv
class CreateForm(forms.ModelForm):
    Dflow = forms.ModelChoiceField(label= 'Name', queryset= dataFlow.objects.all(), empty_label="(Nothing)", widget=forms.Select(attrs={'class': 'form-control', 'name': 'Dflow'}))
    class Meta:
        model = dataFlow
        exclude =['OrganizationId','TargetName','SourceName','FilterName','ProcessName','Name']
        