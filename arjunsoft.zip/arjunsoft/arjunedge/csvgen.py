import beatbox
import csv
import os
def login(username, password, securityToken):
	svc = beatbox.PythonClient()
	svc.login(username, password+securityToken)

def getHeaderNames(data):
	for dicts in data:
		print dicts


def filterBy(filterList):
	filtList = filterList
	result = "WHERE"
	count = 0
	for i in filtList:
		for j in i:
			count += 1
			if(count > (len(filtList)*4) - 1):
				return result
			result += ' '
			result += str(j)
	return result

def preprocess(data):
	for dicts in data:
		if (dicts['OpportunityLineItems'] == ''):
			del dicts['OpportunityLineItems']			
	numOf=5
	returnList = []
	for dicts in data:	
		row = dicts.values()
		l = []
		h = []
		g = []
		for datum in row:
			if isinstance(datum, beatbox.python_client.QueryRecordSet): 
				for values in datum:
					m = []
					rows=values.values()
					for dat in rows:
						m.append(dat)
					h.append(m)
			else:
				#if  isinstance(datum, dict):
				#	ninetails = datum.get('ProductCode',default = None)
				#	l.append(datum)
				l.append(datum)		
		if not h:
			for i in xrange(numOf):
				g.append(' ')
			for el in l:
				g.append(el)
			returnList.append(g)
		else:
			for p in h:
				for element in l:
					p.append(element)
				returnList.append(p)
	return returnList
def preprocess2(data):
	for dicts in data:
		if (dicts['OpportunityLineItems'] == ''):
			del dicts['OpportunityLineItems']			
	numOf=4
	returnList = []
	for dicts in data:	
		row = dicts.values()
		l = []
		h = []
		g = []
		for datum in row:
			if isinstance(datum, beatbox.python_client.QueryRecordSet): 
				for values in datum:
					m = []
					rows =[]
					prod2 = values['Product2']
					rows.append(values['Name'])
					rows.append(values['UnitPrice'])
					rows.append(values['Quantity'])
					rows.append(prod2['ProductCode'])
					#rows=values.values()
					for dat in rows:
						m.append(dat)
					h.append(m)
			else:
				#if  isinstance(datum, dict):
				#	ninetails = datum.get('ProductCode',default = None)
				#	l.append(datum)
				l.append(datum)		
		if not h:
			for i in xrange(numOf):
				g.append(' ')
			for el in l:
				g.append(el)
			returnList.append(g)
		else:
			for p in h:
				for element in l:
					p.append(element)
				returnList.append(p)
	return returnList

def WriteListToCSV(csv_columns, data_list):
	try:
		with open('tempFolder/OppData.csv', 'w') as csvfile:
            		writer = csv.writer(csvfile, dialect='excel', quoting=csv.QUOTE_NONNUMERIC)
            		writer.writerow(csv_columns)
            		for data in data_list:
                			writer.writerow(data)
    	except IOError as (errno, strerror):
            	print("I/O error({0}): {1}".format(errno, strerror))    
    	return            

#probably wont use this unless product starts supporting data withdrawal from objects other than opportunity and opportunity line item
#this gets a list of the objects needed by users  
def getObjects(): 
	username = "hci@intrigosys.com"
	password = "Test12345"
	sf = beatbox._tPartnerNS
	svc = beatbox.PythonClient()
	svc.login(username, password)
	dg = svc.describeGlobal()
	
def runTest():
	username = "hci@intrigosys.com"
	password = "Test12345"
	sf = beatbox._tPartnerNS
	svc = beatbox.PythonClient()
	svc.login(username, password)
	qr = svc.query("SELECT Id, Name,Probability, CloseDate,  (SELECT Name, Product2.ProductCode, Quantity, UnitPrice FROM OpportunityLineItems)  FROM Opportunity " )
	print qr
